class SectionsController < ApplicationController

  require "csv" 
  before_action :set_section, only: %i[ show edit update destroy ]
  before_action :get_aisle, only: %i[ new create index plan export_csv]

  # GET /sections or /sections.json
  def index
    @sections = @aisle.sections.includes(levels: :articles)

  end

  # GET /sections/1 or /sections/1.json
  def show
  end

  # GET /sections/new
  def new
    @section = @aisle.sections.build
  end

  # GET /sections/1/edit
  def edit
  end

 def export_csv
  csv_data = CSV.generate(headers: true) do |csv|

    # FULL HEADER (same as your original export)
    csv << [
      "aisle_num",
      "section_num",
      "level_num",
      "artno",
      "artname_unicode",
      "slid_h",
      "new_loc",
      "badge"
    ]

    # Load everything needed in one go
    placements = Placement
                  .includes(:article, :section, :level)
                  .where(section_id: @aisle.sections.select(:id))

    placements.find_each do |placement|
      art     = placement.article
      section = placement.section
      level   = placement.level

      aisle_num   = section.aisle.aisle_num
      section_num = section.section_num
      level_num   = level.level_num

      # SAME qualify logic as UI
      qualifies_for_mb = art.split_rssq.to_f >= art.palq.to_f * 1.6

      # SAME badge filtering as UI
      filtered_badge =
        if placement.badge.present?
          placement.badge.each_char.select do |badge|
            next true if badge == "O"
            next false if %w[M B].include?(badge) && !qualifies_for_mb
            true
          end.join
        else
          ""
        end

      csv << [
        aisle_num,
        section_num,
        level_num,
        art.artno,
        art.artname_unicode,
        art.slid_h,
        "#{aisle_num}0#{section_num}#{level_num}",
        filtered_badge
      ]
    end
  end

  send_data csv_data,
            filename: "aisle_#{@aisle.aisle_num}_articles.csv",
            type: "text/csv"
end





  def plan
    # The @aisle object is already available via the before_action :get_aisle
    # which is called because :plan is listed in the 'only' array.

    # 1. Instantiate the service with the required objects and parameters.
    # The BinPlannerService must be created in app/services/bin_planner_service.rb
    service = BinPlannerService.new(aisle: @aisle, params: params)
    
    # 2. Execute the service.
    result = service.call

    # 3. Handle the result.
    if result[:success]
      # A successful plan should ideally redirect to a page showing the new layout
      # (e.g., the index page for sections in that aisle).
      redirect_to aisle_sections_path(@aisle), 
                  notice: "Bin planning completed successfully in #{params[:mode].humanize} mode."
    else
      # If the service failed (e.g., validation error, logic error)
      flash.alert = "Bin planning failed: #{result[:message]}"
      # Redirect back to the form's original page to show the error
      redirect_to aisle_sections_path(@aisle), status: :unprocessable_entity
    end
  rescue NameError => e
    # Catching a NameError is a good idea initially if the service or its dependencies 
    # haven't been fully defined yet.
    redirect_to aisle_sections_path(@aisle), 
                alert: "Error: BinPlannerService not ready. #{e.message}"
  end

  def unassign
    # Find the article by the ID passed in the route
    article = Article.find(params[:id])
    
    # Update the article to be unplanned and clear its section assignment
    article.placements.destroy_all
    article.apply_planned_state!
    
    # Redirect back to the sections index page for the current aisle
    redirect_to aisle_sections_path(article.section.aisle), notice: "Article #{article.artno} unassigned successfully."
  rescue ActiveRecord::RecordNotFound
    redirect_back fallback_location: root_path, alert: "Article not found."
  rescue => e
    redirect_back fallback_location: root_path, alert: "Failed to unassign article: #{e.message}"
  end

  def bulk_unassign
  aisle = Aisle.find(params[:id])
  section_ids = aisle.sections.pluck(:id)

  ActiveRecord::Base.transaction do
    Article.where(id: Placement.where(section_id: section_ids).select(:article_id))
       .find_each do |article|
  article.placements.destroy_all
  article.apply_planned_state!
end


    Level.where(section_id: section_ids)
         .where.not(level_num: "00")
         .find_each(&:destroy)

    # If height is NOT NULL in DB, use 0
    Level.where(section_id: section_ids, level_num: "00")
         .update_all(level_height: 0)
  end

  redirect_to aisle_sections_path(aisle), notice: "Bulk unassign complete for Aisle #{aisle.aisle_num}."
rescue => e
  redirect_to aisle_sections_path(aisle), alert: "Bulk unassign failed: #{e.message}"
end




  # ACTION ADDED: POST /aisles/:aisle_id/sections/plan (Handles the planning process)
  
  # POST /sections or /sections.json
  def create
    @section = @aisle.sections.build(section_params)

    respond_to do |format|
      if @section.save
        format.html { redirect_to @section, notice: "Section was successfully created." }
        format.json { render :show, status: :created, location: @section }
      else
        format.html { render :new, status: :unprocessable_entity }
        format.json { render json: @section.errors, status: :unprocessable_entity }
      end
    end
  end

  # PATCH/PUT /sections/1 or /sections/1.json
  def update
    respond_to do |format|
      if @section.update(section_params)
        format.html { redirect_to @section, notice: "Section was successfully updated.", status: :see_other }
        format.json { render :show, status: :ok, location: @section }
      else
        format.html { render :edit, status: :unprocessable_entity }
        format.json { render json: @section.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /sections/1 or /sections/1.json
  def destroy
    @section.destroy!

    respond_to do |format|
      format.html { redirect_to aisle_sections_path(@section.aisle), notice: "Section was successfully destroyed.", status: :see_other }
      format.json { head :no_content }
    end
  end

  private
    # Use callbacks to share common setup or constraints between actions.
    def set_section
      @section = Section.find(params[:id])
    end

    def get_aisle
      @aisle = Aisle.find(params[:aisle_id])
    end

    # Only allow a list of trusted parameters through.
    def section_params
      params.require(:section).permit(:section_num, :section_depth, :section_height, :section_width, :aisle_id)
    end
end
